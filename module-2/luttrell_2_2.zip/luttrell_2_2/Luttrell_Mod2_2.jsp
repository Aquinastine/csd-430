<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*, java.io.*, org.json.*" %>

<%--
Jason Luttrell
CSD430-T301
Module 2.2 - JSP Scriptlets
3/23/26
--%>

<%
    class CountryRating {
        String country;
        int cuisine;
        int history;
        int cost;

        CountryRating(String country, int cuisine, int history, int cost) {
            this.country = country;
            this.cuisine = cuisine;
            this.history = history;
            this.cost = cost;
        }
    }

    List<CountryRating> countries = new ArrayList<>();

    try {
        String filePath = application.getRealPath("LuttrellCountryData.json");
        BufferedReader reader = new BufferedReader(new FileReader(filePath));

        StringBuilder jsonText = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            jsonText.append(line);
        }

        reader.close();

        JSONArray jsonArray = new JSONArray(jsonText.toString());

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);

            countries.add(new CountryRating(
                obj.getString("country"),
                obj.getInt("cuisine"),
                obj.getInt("history"),
                obj.getInt("cost")
            ));
        }

    } catch (Exception e) {
        out.println("<p style='color:red;'>Error loading JSON: " + e.getMessage() + "</p>");
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Module 2 Assignment - JSP Scriptlets</title>
    <link rel="stylesheet" href="css/LuttrellMatrixStyles.css">
</head>
<body>
    <div class="matrix-rain"></div>

    <div class="page-wrapper">
        <div class="card">
            <div class="course-name">CSD-430 Server Side Development
            </div>
            <h1 class="title">Module 2 Assignment - JSP Scriptlets</h1>
            <p class="subtitle">Countries Visited</p>
        </div>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Country</th>
                        <th>Cuisine</th>
                        <th>History</th>
                        <th>Cost of Visiting</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        for (CountryRating item : countries) {
                    %>
                    <tr>
                        <td><%= item.country %></td>
                        <td class="stars">
                            <%
                                for (int i = 1; i <= 5; i++) {
                                    if (i <= item.cuisine) {
                            %>
                                <span class="filled">★</span>
                            <%
                                    } else {
                            %>
                                <span class="empty">☆</span>
                            <%
                                    }
                                }
                            %>
                        </td>
                        <td class="stars">
                            <%
                                for (int i = 1; i <= 5; i++) {
                                    if (i <= item.history) {
                            %>
                                <span class="filled">★</span>
                            <%
                                    } else {
                            %>
                                <span class="empty">☆</span>
                            <%
                                    }
                                }
                            %>
                        </td>
                        <td class="dollars">
                            <%
                                for (int i = 1; i <= 5; i++) {
                                    if (i <= item.cost) {
                            %>
                                <span class="dollar-filled">$</span>
                            <%
                                    } else {
                            %>
                                <span class="dollar-empty">$</span>
                            <%
                                    }
                                }
                            %>
                        </td>
                    </tr>
                    <%
                        }
                    %>
                </tbody>
            </table>

            <div class="note">
                Cuisine and History are rated with stars. Cost of Visiting is rated with dollar signs.
            </div>
        </div>
        <div class="card">
            <h1 class="subtitle">Module 2 Assignment - JSP Scriptlets</h1>
            <p class="footer-name">Jason Luttrell</p>
            <p class="footer-date">March 23, 2026</p>
        </div>
    </div>
</body>
</html>